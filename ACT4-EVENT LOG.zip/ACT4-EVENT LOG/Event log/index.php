<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
		<style>
		body{
			background: url(1.jpg);
  			background-repeat: no-repeat;
 			background-size: auto;
			-webkit-background-size: cover;
			letter-spacing: 1px;
		}
		::placeholder{ /* Chrome, Firefox, Opera, Safari 10.1+ */
 			color: #E3F4FC;
 			opacity: 1; /* Firefox */
		}
		.container{
			height: 480px;
			width: 450px;
			top: 70px;
			left: 470px;
			border-radius: 20px;
			 --borderWidth: 3px;
			 background: #1D1F20;
			 position: relative;
			 border-radius: var(--borderWidth);
			
		}
		.container:after {
			 content: '';
			 position: absolute;
			 top: calc(-1 * var(--borderWidth));
			 left: calc(-1 * var(--borderWidth));
			 height: calc(100% + var(--borderWidth) * 2);
			 width: calc(100% + var(--borderWidth) * 2);
			 background: linear-gradient(60deg, #f79533, #f37055, #ef4e7b, #a166ab, #5073b8, #1098ad, #07b39b, #6fba82);
			 border-radius: calc(2 * var(--borderWidth));
			 z-index: -1;
			 animation: animatedgradient 3s ease alternate infinite;
			 background-size: 300% 300%;
		}
		@keyframes animatedgradient {
			0% {
				background-position: 0% 50%;
			}
			50% {
				background-position: 100% 50%;
			}
			100% {
				background-position: 0% 50%;
			}
		}
		img{
			border-radius: 50%;
			margin-bottom: 10px;
			transition: all .5s;
			border: 3.5px solid black;
		}
		img:hover{

  		transform: scale(1.3) rotate(10deg);
		}
		.ca{
			color: #40DDE4;
		}
		.boxer{
			width: 320px;
			height: 400px;
			
			color: white;
			top: 50%;
			left: 50%;
			position: absolute;
			transform: translate(-50%, -50%);
			box-sizing: border-box;
			padding: 30px 30px;
		}
		.pik{
			width: 100px;
			height: 100px;
			border-radius: 50%;
			position: absolute;
			top: -50px;
			left: calc(50% - 50px);
		}
		 .boxer p {
			margin: 0;
			padding: 0;
			font-weight: bold;
		}
		.boxer input{
			width: 100%;
			margin-bottom: 20px;

		}
		.boxer input[type="text"], input[type="password"]{
			border: none;
			border-bottom: 1px solid #fff;
			background: transparent;
			outline: none;
			height: 40px;
			color: white;
			font-size: 16px;	
		}
		button{
			width: 100%;
			margin-bottom: 20px;
			border: none;
			outline: none;
			height: 40px;
			background: #000000;
			color: #fff;
			font-size: 18px;
			border border-radius: 20px;
		}
		button:hover{
			cursor: pointer;
			box-shadow: 0px 0px 5px white;
		}

		
</style>
</head>
<body>
	<div class="container">
     <form action="login.php" method="post">
     	<div class="boxer">
            <center><img src="i.png" height="150px" width="150px"></center>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
     	<input type="text" name="uname" placeholder="Username"><br>

     	<input type="password" name="password" placeholder="Password"><br>
            
        <button  type="submit">Login</button>
<br/><br>
			<a href="changpass.php" class="ca">Forgot Password?</a><br><br>
     	    
          
     </form>
 </div>
</body>
</html>