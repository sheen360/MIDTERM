<!DOCTYPE html>
<html>
<head>
	<title>Change Password</title>
	<style>
		body{
			margin: 0;
			padding: 0;
			background-image: url("1.jpg");
			background-size: cover;
			 

		}
		.container{
			height: 480px;
			width: 450px;
			top: 70px;
			left: 470px;
			border-radius: 20px;
			 --borderWidth: 3px;
			 background: #1D1F20;
			 position: relative;
			 border-radius: var(--borderWidth);
			
		}
		.container:after {
			 content: '';
			 position: absolute;
			 top: calc(-1 * var(--borderWidth));
			 left: calc(-1 * var(--borderWidth));
			 height: calc(100% + var(--borderWidth) * 2);
			 width: calc(100% + var(--borderWidth) * 2);
			 background: linear-gradient(60deg, #f79533, #f37055, #ef4e7b, #a166ab, #5073b8, #1098ad, #07b39b, #6fba82);
			 border-radius: calc(2 * var(--borderWidth));
			 z-index: -1;
			 animation: animatedgradient 3s ease alternate infinite;
			 background-size: 300% 300%;
		}
		.boxer{
			width: 400px;
			height: 450px;
			background: #DCDCDC;
			color: dimgray;
			top: 50%;
			left: 50%;
			position: absolute;
			transform: translate(-50%, -50%);
			box-sizing: border-box;
			padding: 30px 30px;
			border-radius: 20px;
			box-shadow: 2px 2px 3px black;
			
		}
		.pik{
			width: 100px;
			height: 100px;
			border-radius: 50%;
			position: absolute;
			top: -50px;
			left: calc(50% - 50px);
		}
		a{
			margin-top: 20px;
		}
		.h1{
			margin: 0;
			padding: 0 0 20px;
			text-align: center;
			font-size: 22px;
		}
		.boxer p {
			margin: 1;
			padding: 0;
			font-weight: bold;
		}
		.boxer input{
			width: 100%;
			margin-bottom: 20px;
		}
		.boxer input[type="text"], input[type="password"]{
			border: none;
			border-bottom: 2px solid #fff;
			background: transparent;
			outline: none;
			height: 40px;
			color: black;
			font-size: 16px;	
		}
		.boxer input[type="submit"]{
			border: none;
			outline: none;
			height: 40px;
			background: #008CBA;
			color: #fff;
			font-size: 18px;
			border border-radius: 20px;
			box-shadow: 2px 2px 2px black;
			
		}
		.boxer p{
			font-size: 30px;
			font-family: "Times New Roman", serif;
			color: #3E373C;
			margin-top: 1px;
		}
		button{
			width: 100%;
			font-family: rockwell;
			font-weight: bold;
			letter-spacing: 1px;
			background: #118F48;
			border: none;
			outline: none;
			height: 40px; 
			font-size: 18px;
			border border-radius: 20px;
			margin-top: 40px;
		}
		button:hover{
			cursor: pointer;
			box-shadow: 0px 0px 5px white;
			background:  #20A3A3;
		}
</style>
</head>
<body>
	<div class="boxer">
     <form action="foxcheck.php" method="post">
     	<center><p>FORGOT PASSWORD</p></center>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

          <?php if (isset($_GET['success'])) { ?>
               <p class="success"><?php echo $_GET['success']; ?></p>
          <?php } ?>


          <?php if (isset($_GET['uname'])) { ?>
               <input type="text" 
                      name="username" 
                      placeholder="Username"
                      value="<?php echo $_GET['uname']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="uname" 
                      placeholder="Username"><br>
          <?php }?>


     	
     	<input type="password" 
                 name="password" 
                 placeholder="Password"><br>

        
          <input type="password" 
                 name="re_password" 
                 placeholder=" Confirm Password"><br>
<a href="index.php" class="ca">Already have an account?</a><br><br>
     	<button type="submit">Update Password</button>
          
     </form>
</body>
</html>