
<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['username'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<style>
		body{
			background: url(1.jpg);
  			background-repeat: no-repeat;
 			background-size: auto;
			-webkit-background-size: cover;
			letter-spacing: 1px;

		}
		fieldset{
			text-align: center;
			position: absolute;
			background: rgba(0,0,0,0.9);
			top: 160px;
			left: 410px;
			width: 500px;
			border-radius: 20px;
			 --borderWidth: 3px;
			 border: 2px solid lightgreen;
			 position: relative;
			 border-radius: var(--borderWidth);
			 overflow:hidden;
		}
		.container{
			height: 480px;
			width: 450px;
			top: 70px;
			left: 470px;
			
			
			
		}
		fieldset:after {
			 content: '';
			 position: absolute;
			 top: calc(-1 * var(--borderWidth));
			 left: calc(-1 * var(--borderWidth));
			 height: calc(100% + var(--borderWidth) * 2);
			 width: calc(100% + var(--borderWidth) * 2);
			 background: linear-gradient(60deg, #f79533, #f37055, #ef4e7b, #a166ab, #5073b8, #1098ad, #07b39b, #6fba82);
			 border-radius: calc(2 * var(--borderWidth));
			 z-index: -1;
			 animation: animatedgradient 3s ease alternate infinite;
			 background-size: 300% 300%;
		}
		@keyframes animatedgradient {
			0% {
				background-position: 0% 50%;
			}
			50% {
				background-position: 100% 50%;
			}
			100% {
				background-position: 0% 50%;
			}
		}
		h1{
			font-size: 40px;
			color: #21AB58;

		}
 
        button{
			width:50%;
			font-family: rockwell;
			font-weight: bold;
			letter-spacing: 1px;
			background: #118F48;
			border: none;
			outline: none;
			height: 40px; 
			font-size: 18px;
			border-radius: 20px;
			margin-top: 30px;
			margin-bottom: 10px;
		}
		button:hover{
			cursor: pointer;
			box-shadow: 0px 0px 5px white;
			background:  #20A3A3;
		}
        
		
		</style>
	<title>HOME</title>
	
</head>
<body>
	<div class="container">
	<fieldset>
     <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
	
   	
	<a type="submit" href="display.php" >View Activity </a>
	<br>
	<form action="login.php" method="post">
		<button type="submit" href="logout.php">Logout</button>
    </form>
	</fieldset>
</div>
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>                            		                            