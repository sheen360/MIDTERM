<html>
	<head>
		<style>
		body{
			background: url(1.jpg);
  			background-repeat: no-repeat;
 			background-size: auto;
			-webkit-background-size: cover;
			letter-spacing: 1px;
		}
		label{
			font-size: 40px;
			color: #21AB58;

		}
		fieldset{
			text-align: center;
			position: absolute;
			top: 150px;
			left: 500px;
			width: 300px;
			height: 200px;
			background: rgba(0,0,0,0.5);
		}
		.boxer{
			
			 
			position:relative;
			box-sizing: border-box;
			padding: 30px 30px;
			 
		}
		.pik{
			width: 100px;
			height: 100px;
			border-radius: 50%;
			position: absolute;
			top: -50px;
			left: calc(50% - 50px);
		}
		 
		.ca{
			color: #40DDE4;
		}
		.boxer p {
			margin: 0;
			padding: 0;
			font-weight: bold;
		}
		.boxer input{
			width: 100%;
			margin-bottom: 35px;
			margin-top: 20px;
		}
		.boxer input[type="text"], input[type="password"]{
			border: none;
			border-bottom: 1px solid #fff;
			background: transparent;
			outline: none;
			height: 40px;
			color: white;
			font-size: 16px;	
		}
		.boxer input[type="submit"]{
			border: none;
			outline: none;
			height: 40px;
			background: #008CBA;
			color: #fff;
			font-size: 18px;
			border border-radius: 20px;
		}
		button{
			width: 100%;
			font-family: rockwell;
			font-weight: bold;
			letter-spacing: 1px;
			background: #118F48;
			border: none;
			outline: none;
			height: 40px; 
			font-size: 18px;
			border border-radius: 20px;
		}
		button:hover{
			cursor: pointer;
			box-shadow: 0px 0px 5px white;
			background:  #20A3A3;
		}
</style>
		<title>
			
			</title>
		</head>
	<body>
		<div class="boxer">
		<fieldset>
		<form action="codex.php" method="post">
			 
		
		 <label><center>Enter Username</center></label>
			
          <?php if (isset($_GET['uname'])) { ?>
               <input type="text" 
                      name="username" 
                      placeholder="Username"
                      value="<?php echo $_GET['uname']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="uname" 
                      placeholder="Username"><br>
          <?php }?>
			<button type="submit" value="Send">Send</button>
		</form>
		<?php ?> 
		</fieldset>
		</div>
		</body>
	</html>

