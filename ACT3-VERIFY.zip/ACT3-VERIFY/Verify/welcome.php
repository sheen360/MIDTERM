<?php 
session_start();
  
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    
    <div class="welcome">
        <h1 style="color: yellow; text-shadow: 0px 0px 8px brown;">Welcome!</h1>
        <a href="logout.php">Sign Out</a>    
    </div>
   
</body>
</html>