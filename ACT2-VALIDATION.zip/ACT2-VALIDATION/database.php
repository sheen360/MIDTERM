<?php

$servername= "localhost";
$usern= "root";
$password = "";
$dbname = "accounts";
$conn = mysqli_connect($servername, $usern, $password, $dbname);

?>