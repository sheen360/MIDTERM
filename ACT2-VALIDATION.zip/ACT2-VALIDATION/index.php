<!DOCTYPE html>
<html>
<head>
	<title>Mystera Legacy</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

     <form action="login.php" method="post">
     	
          <h1 style="color: yellow;">Welcome Adventurer!</h1>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>


     	<label>Username</label>
     	<input type="text" name="uname" placeholder="Enter Username"><br>

     	<label>Password&nbsp;</label>
     	<input type="password" name="password" placeholder="Enter Password">
          <br>
     	<button type="submit">Login</button>
          <a href="signup.php" class="ca">Register</a>
     </form>
</body>
</html>