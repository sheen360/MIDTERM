<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['email'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	 <button onclick="document.location='login.php'">LOGOUT</button>
     <h2 style="background-color: #F1E938">Welcome <?php echo $_SESSION['name']; ?>!</h2>
     <h2 style="background-color: #F1E938"> A new Adventurer arrives!</h2
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>