<?php

$uname="ADMIN";
$pwd="ADMIN123";

session_start();
 	
 	if(isset($_SESSION['uname'])){
 		echo "<h2> Welcome!</h2>";

		echo "<br><a href='logout.php'><input type=button name=back value=back></a>";

 	}
 	else{
 		if($_POST['uname']==$uname && $_POST['pwd']==$pwd){

 		$_SESSION['uname']=$uname;

 		echo "<script>location.href='welcome.php'</script?>";
 		}
 		else{
 			echo "<script>alert('Username and Password does not match!')</script>";

 			echo "<script>location.href='login.php'</script>";

 		}
 	}
?>