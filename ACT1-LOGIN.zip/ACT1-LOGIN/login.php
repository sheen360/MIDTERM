<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
</head>
<body>
	<center>
		<form action="welcome.php" method="post">
			<div class="container">
				<div class="header">
					<h1>Welcome!</h1>			
				</div>
				<div class="main">
					<span>
						<i class="fa fa-user"></i>
						<input type="Username" placeholder="Username" name="uname"required>
					</span><br>
					<span>
						<i class="fa fa-lock"></i>
						<input type="password" placeholder="Password" name="pwd"required>
					</span><br>
					<button type="submit" name="submit" value='login'>Login</button>
				</div>
			</div>
		</form>
	</center>
</body>
</html>

<style>
body {
	font-family: sans-serif;	
	background-image: url(1.jpg);
	background-position: center;
	background-repeat: no-repeat;
	overflow: hidden;
	background-size: cover;
}

.container {
	width: 380px;
	margin:5% auto;
	border-radius: 25px;
	background-color: rgba(0,0,0,0.70);
	box-shadow: 0 0 17px #333;
}

.header {
	text-align: center;
	padding-top: 75px;
}

.header h1 {
	color: #ffffff;
	font-size: 45px;
	margin-bottom: 80px;
}

.main {
	text-align: center;
}

.main input, button {
	width: 300px;
	height: 40px;
	border:none;
	outline: none;
	padding-left: 40px;
	box-sizing: border-box;
	font-size: 15px;
	color: #333;
	margin-bottom: 40px;
}

.main button {
	padding-left: 0;
	background-color: #83acf1;
	letter-spacing: 1px;
	font-weight: bold;
	margin-bottom: 70px;
}

.main button:hover {
	box-shadow: 2px 2px 5px #555;
	background-color: #7799d4;
}
.main input:hover {
	box-shadow: 2px 2px 5px #555;
	background-color: #ddd;
}
.main i {
	position: absolute;
	left: 15px;
	color: #333;
	font-size: 16px;
	top: 2px;
}
.main span {
	position: relative;
}

</style>